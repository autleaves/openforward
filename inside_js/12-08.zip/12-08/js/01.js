
const res = confirm('確認してください');
if(res) {
    alert('確認しました');
}