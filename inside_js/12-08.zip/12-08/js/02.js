
const res = confirm('どちらかクリックしてください');
if(res) {
    console.log('OKがクリックされました');
} else {
    console.log('キャンセルがクリックされました');
}