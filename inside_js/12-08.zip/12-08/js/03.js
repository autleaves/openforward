
const delayTask = () => {
    console.log('３秒経ったらこんにちは');
}
setTimeout(delayTask, 3000);