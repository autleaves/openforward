
open('https://tmc.tsuzuki.ac.jp/', '東京マルチ・AI専門学校',
    'left=200, top=300,width=800,height=600');