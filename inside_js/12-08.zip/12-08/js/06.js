
open('https://www.tokyo-zoo.net/zoo/ueno');
console.log(location.protocol);