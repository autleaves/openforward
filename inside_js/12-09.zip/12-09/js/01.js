
const target = document.querySelector('#kawaru');
target.textContent = 'JavaScriptで変えました';
