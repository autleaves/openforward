
const elements = document.querySelectorAll('.sample');
for (const elem of elements) {
    console.log(elem);
}
