
const target = document.querySelector('img');
target.width = 600;
