
const target = document.querySelector('.profile');
target.dataset.id = 1218;
target.dataset.userName = 'コウヨウ';
target.textContent = 'コウヨウ';
console.log(target);
