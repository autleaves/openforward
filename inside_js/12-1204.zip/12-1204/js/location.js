
open('https://tmc.tsuzuki.ac.jp/', '東京マルチ・AI専門学校','width=800,height=600');
console.log(location.href);
console.log(location.protocol);
console.log(location.hostname);