
function delayTask() {
    console.log('一秒後に実行する');
}
setTimeout(delayTask, 1000);