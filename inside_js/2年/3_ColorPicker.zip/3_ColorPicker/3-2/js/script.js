

console.log("準備完了");