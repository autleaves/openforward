

console.log(document.querySelector('#colorPicker').value);

document.querySelector('#colorText').textContent = 'カラーコード';